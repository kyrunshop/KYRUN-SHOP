package com.kyrunshop.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String = "",
    val category: String = "Umum",
    val costPrice: Long,
    val sellPrice: Long,
    val stock: Int
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val total: Long,
    val paymentMethod: String,
    val cashier: String
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Long
)

@Dao
interface StoreDao {
    @Query("SELECT * FROM products ORDER BY name") fun products(): Flow<List<Product>>
    @Query("SELECT * FROM sales ORDER BY createdAt DESC") fun sales(): Flow<List<Sale>>
    @Insert suspend fun addProduct(product: Product)
    @Update suspend fun updateProduct(product: Product)
    @Delete suspend fun deleteProduct(product: Product)
    @Insert suspend fun addSale(sale: Sale): Long
    @Insert suspend fun addItems(items: List<SaleItem>)
    @Query("UPDATE products SET stock = stock - :qty WHERE id = :id AND stock >= :qty")
    suspend fun reduceStock(id: Long, qty: Int): Int
    @Query("SELECT COALESCE(SUM(total),0) FROM sales WHERE createdAt >= :start") suspend fun salesSince(start: Long): Long
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1") suspend fun productById(id: Long): Product?
}

@Database(entities = [Product::class, Sale::class, SaleItem::class], version = 1, exportSchema = false)
abstract class StoreDatabase : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var INSTANCE: StoreDatabase? = null
        fun get(context: Context): StoreDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, StoreDatabase::class.java, "kyrun-shop.db").build().also { INSTANCE = it }
        }
    }
}
