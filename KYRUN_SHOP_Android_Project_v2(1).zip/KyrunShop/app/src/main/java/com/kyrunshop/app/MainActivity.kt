package com.kyrunshop.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private fun rupiah(value: Long) = NumberFormat.getCurrencyInstance(Locale("in", "ID")).format(value)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KyrunApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KyrunApp() {
    val context = LocalContext.current
    val dao = remember { StoreDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    val products by dao.products().collectAsState(initial = emptyList())
    val sales by dao.sales().collectAsState(initial = emptyList())
    var user by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Pemilik") }
    var page by remember { mutableStateOf("Dashboard") }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Umum") }
    var cart by remember { mutableStateOf(mapOf<Long, Int>()) }
    var payment by remember { mutableStateOf("Tunai/COD") }
    var message by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF172B4D), secondary = androidx.compose.ui.graphics.Color(0xFFF28C28))) {
        if (user.isBlank()) {
            LoginScreen(onLogin = { n, r -> user = n; role = r })
        } else {
            Scaffold(
                topBar = { TopAppBar(title = { Column { Text("KYRUN SHOP", fontWeight = FontWeight.Bold); Text("$page • $user ($role)", style = MaterialTheme.typography.labelSmall) } }, actions = { IconButton(onClick = { user = "" }) { Icon(Icons.Default.Logout, "Keluar") } }) },
                bottomBar = {
                    NavigationBar {
                        listOf("Dashboard", "Kasir", "Produk", "Laporan").forEach { item ->
                            NavigationBarItem(selected = page == item, onClick = { page = item }, icon = {
                                Icon(when(item) { "Kasir" -> Icons.Default.PointOfSale; "Produk" -> Icons.Default.Inventory2; "Laporan" -> Icons.Default.Assessment; else -> Icons.Default.Home }, item)
                            }, label = { Text(item) })
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                    when(page) {
                        "Dashboard" -> {
                            Text("Ringkasan toko", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SummaryCard("Produk", products.size.toString(), Modifier.weight(1f))
                                SummaryCard("Transaksi", sales.size.toString(), Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(8.dp))
                            SummaryCard("Omzet hari ini", rupiah(sales.filter { it.createdAt >= dayStart() }.sumOf { it.total }), Modifier.fillMaxWidth())
                            Spacer(Modifier.height(16.dp))
                            Text("Transaksi terbaru", fontWeight = FontWeight.Bold)
                            sales.take(5).forEach { Text(" #${it.id} • ${it.paymentMethod} • ${rupiah(it.total)}", Modifier.padding(vertical=6.dp)) }
                        }
                        "Produk" -> {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Daftar produk", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                if (role == "Pemilik") Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("Tambah") }
                            }
                            LazyColumn { items(products) { p ->
                                ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("${p.category} • Stok ${p.stock} • Modal ${rupiah(p.costPrice)}") }, trailingContent = { Text(rupiah(p.sellPrice), fontWeight = FontWeight.Bold) })
                                HorizontalDivider()
                            } }
                        }
                        "Kasir" -> {
                            Text("Pilih produk", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            LazyColumn(Modifier.weight(1f)) {
                                items(products) { p ->
                                    ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("Stok ${p.stock} • ${rupiah(p.sellPrice)}") }, trailingContent = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text((cart[p.id] ?: 0).toString(), Modifier.padding(horizontal=8.dp))
                                            IconButton(onClick = { if ((cart[p.id] ?: 0) < p.stock) cart = cart + (p.id to ((cart[p.id] ?: 0)+1)) }) { Icon(Icons.Default.Add, "Tambah") }
                                            IconButton(onClick = { val q=(cart[p.id] ?: 0)-1; cart = if(q<=0) cart-p.id else cart+(p.id to q) }) { Icon(Icons.Default.Remove, "Kurangi") }
                                        }
                                    })
                                    HorizontalDivider()
                                }
                            }
                            val total = products.sumOf { it.sellPrice * (cart[it.id] ?: 0) }
                            Text("Total: ${rupiah(total)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Metode pembayaran")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Tunai/COD","Transfer","QRIS").forEach { m -> FilterChip(selected=payment==m,onClick={payment=m},label={Text(m)}) }
                            }
                            Button(onClick = {
                                scope.launch {
                                    if (cart.isEmpty()) { message = "Keranjang masih kosong"; return@launch }
                                    val invalid = cart.any { (id,q) -> (dao.productById(id)?.stock ?: 0) < q }
                                    if (invalid) { message = "Stok tidak mencukupi"; return@launch }
                                    val sid = dao.addSale(Sale(total=total,paymentMethod=payment,cashier=user))
                                    val items = cart.mapNotNull { (id,q) -> dao.productById(id)?.let { p -> SaleItem(saleId=sid,productId=id,productName=p.name,quantity=q,unitPrice=p.sellPrice) } }
                                    items.forEach { dao.reduceStock(it.productId,it.quantity) }
                                    dao.addItems(items); cart = emptyMap(); message = "Transaksi #$sid berhasil disimpan"
                                }
                            }, modifier=Modifier.fillMaxWidth()) { Text("Simpan transaksi") }
                            if (message.isNotBlank()) Text(message, color=MaterialTheme.colorScheme.primary)
                        }
                        "Laporan" -> {
                            Text("Laporan penjualan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            SummaryCard("Total seluruh penjualan", rupiah(sales.sumOf { it.total }), Modifier.fillMaxWidth())
                            SummaryCard("Transaksi tercatat", sales.size.toString(), Modifier.fillMaxWidth())
                            sales.forEach { Text("${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id","ID")).format(it.createdAt)} • ${it.paymentMethod} • ${rupiah(it.total)}", Modifier.padding(vertical=6.dp)) }
                        }
                    }
                }
            }
            if (showAdd) AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Tambah produk") },
                text = { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name,{name=it},label={Text("Nama produk")})
                    OutlinedTextField(category,{category=it},label={Text("Kategori")})
                    OutlinedTextField(cost,{cost=it},label={Text("Harga modal")})
                    OutlinedTextField(price,{price=it},label={Text("Harga jual")})
                    OutlinedTextField(stock,{stock=it},label={Text("Stok awal")})
                } },
                confirmButton = { TextButton(onClick = {
                    val c=cost.toLongOrNull(); val s=price.toLongOrNull(); val st=stock.toIntOrNull()
                    if(name.isNotBlank() && c!=null && s!=null && st!=null && c>=0 && s>=0 && st>=0) {
                        scope.launch { dao.addProduct(Product(name=name.trim(),category=category,costPrice=c,sellPrice=s,stock=st)); name="";cost="";price="";stock="";showAdd=false }
                    } else message="Periksa kembali data produk"
                }) { Text("Simpan") } },
                dismissButton = { TextButton(onClick={showAdd=false}) { Text("Batal") } }
            )
        }
    }
}

@Composable private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical=4.dp)) { Column(Modifier.padding(16.dp)) { Text(title, style=MaterialTheme.typography.labelMedium); Text(value, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold) } }
}
@Composable private fun LoginScreen(onLogin: (String,String)->Unit) {
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Pemilik") }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
            Text("KYRUN SHOP", style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.ExtraBold)
            Text("Sistem Kasir Offline", color=MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(name,{name=it},label={Text("Nama pengguna")},singleLine=true)
            Spacer(Modifier.height(8.dp))
            Text("Masuk sebagai")
            Row { FilterChip(selected=role=="Pemilik",onClick={role="Pemilik"},label={Text("Pemilik")}); Spacer(Modifier.width(8.dp)); FilterChip(selected=role=="Karyawan",onClick={role="Karyawan"},label={Text("Karyawan")}) }
            Spacer(Modifier.height(16.dp))
            Button(onClick={onLogin(name.trim().ifBlank { role },role)}, enabled=name.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Text("Masuk") }
            Text("Catatan prototipe: autentikasi PIN dan pengelolaan akun perlu diaktifkan sebelum operasional.", style=MaterialTheme.typography.bodySmall)
        }
    }
}
private fun dayStart(): Long {
    val c=java.util.Calendar.getInstance()
    c.set(java.util.Calendar.HOUR_OF_DAY,0); c.set(java.util.Calendar.MINUTE,0); c.set(java.util.Calendar.SECOND,0); c.set(java.util.Calendar.MILLISECOND,0)
    return c.timeInMillis
}
