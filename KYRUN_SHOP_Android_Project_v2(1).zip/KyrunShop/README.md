# KYRUN SHOP — Android POS starter

Starter project Android native (Kotlin + Jetpack Compose + Room) untuk toko offline.

## Fitur yang sudah ada pada starter
- Login tampilan pemilik/karyawan (belum autentikasi aman/PIN).
- Dashboard ringkasan.
- Produk: tambah produk, kategori, harga modal/jual, stok.
- Kasir: keranjang sederhana, metode Tunai/COD, Transfer, QRIS.
- Transaksi tersimpan lokal di Room/SQLite.
- Stok berkurang saat transaksi.
- Laporan ringkas.

## Membuka project
1. Ekstrak ZIP.
2. Buka folder `KyrunShop` melalui Android Studio (versi yang mendukung AGP 8.7.3 dan JDK 17).
3. Tunggu Gradle Sync dan unduh dependensi yang diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Setelah berhasil, Android Studio menampilkan tautan **locate** ke APK hasil build (biasanya `app/build/outputs/apk/debug/app-debug.apk`).
6. Pindahkan APK ke HP Android dan izinkan instalasi dari sumber tersebut jika diminta.

## Batasan yang perlu diselesaikan sebelum dipakai di toko
- Ini starter/MVP awal, bukan APK siap produksi.
- Login saat ini hanya pemilih nama/role, belum ada PIN, manajemen akun, atau pembatasan hak akses yang aman.
- Printer Bluetooth belum diimplementasikan. Perlu penyesuaian ESC/POS sesuai merek/model printer dan izin Bluetooth Android.
- QRIS/transfer hanya dicatat sebagai metode pembayaran; verifikasi otomatis memerlukan integrasi penyedia pembayaran dan internet.
- Database masih lokal di satu perangkat; belum ada sinkronisasi antar-HP, backup otomatis, ekspor, atau pemulihan data.
- Perlu pengujian perangkat nyata, validasi transaksi bersamaan, dan backup sebelum penggunaan operasional.

## Catatan offline
Transaksi dan katalog disimpan lokal di SQLite sehingga fitur inti tetap berjalan tanpa internet. QRIS/transfer perlu diverifikasi secara manual saat offline.
